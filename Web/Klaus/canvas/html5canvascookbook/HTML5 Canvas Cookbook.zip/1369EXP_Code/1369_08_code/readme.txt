Note: Since Canvas Hero uses getImageData(), the game must run on a web server or else the 
JS interpreter will throw a security error.  You can see the game here:

http://www.html5canvastutorials.com/cookbook/